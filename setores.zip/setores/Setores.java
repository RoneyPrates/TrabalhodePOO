
package com.mycompany.setores;
import java.util.Scanner;

/**
 *
 * @author roney
 */
public class Setores {

    public static void main(String[] args) {        
        Scanner  e = new Scanner(System.in);
                
        String local;
        System.out.println("Qual é o seu setor?");
        local = e.nextLine();
    
    if( local != null)switch (local) {
        case "norte", "Norte", "NORTE" -> System.out.println("Acesso liberado, favor se dirigir ao setor norte do estádio");
        case "sul", "Sul", "SUL" -> System.out.println("Acesso liberado, favor se dirigir ao setor sul do estádio");
        case "leste", "Leste", "LESTE" -> System.out.println("Acesso liberado, favor se dirigir ao setor leste do estádio");
        case "oeste", "Oeste", "OESTE" -> System.out.println("Acesso liberado, favor se dirigir ao setor oeste do estádio");
        default -> System.out.println("Acesso recusado, adicione um setor válido");
    }
    else {
        System.out.println("Acesso recusado, adicione um setor válido");
        }
        Scanner c = new Scanner(System.in);
        int cadeira;
        System.out.println("Digite o numero da cadeira");
        cadeira = c.nextInt();
        
        if( cadeira >= 0 || cadeira < 1000){
        System.out.println("Cadeira selecionada foi a"+cadeira+ "no setor norte");
        }
        else{
        System.out.println("Cadeira inválida");
        }
    }
        }   

       
